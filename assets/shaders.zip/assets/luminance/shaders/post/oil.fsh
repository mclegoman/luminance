#version 150

in vec2 texCoord;

uniform sampler2D InSampler;
uniform vec2 InSize;
uniform int Radius;

out vec4 fragColor;

void main() {
    float radiusSquare = float((Radius + 1) * (Radius + 1));
    vec3 colors[4];
    vec3 colorsSquare[4];
    for (int a = 0; a < 4; a++) {
        colors[a] = vec3(0.0);
        colorsSquare[a] = vec3(0.0);
    }
    for (int a = -Radius; a <= 0; a++) {
        for (int b = -Radius; b <= 0; b++) {
            vec3 col = texture(InSampler, texCoord + vec2(b, a) / InSize).rgb;
            colors[0] += col;
            colorsSquare[0] += col * col;
        }
    }
    for (int a = -Radius; a <= 0; a++) {
        for (int b = 0; b <= Radius; b++) {
            vec3 col = texture(InSampler, texCoord + vec2(b, a) / InSize).rgb;
            colors[1] += col;
            colorsSquare[1] += col * col;
        }
    }
    for (int a = 0; a <= Radius; a++) {
        for (int b = 0; b <= Radius; b++) {
            vec3 col = texture(InSampler, texCoord + vec2(b, a) / InSize).rgb;
            colors[2] += col;
            colorsSquare[2] += col * col;
        }
    }
    for (int a = 0; a <= Radius; a++) {
        for (int b = -Radius; b <= 0; b++) {
            vec3 col = texture(InSampler, texCoord + vec2(b, a) / InSize).rgb;
            colors[3] += col;
            colorsSquare[3] += col * col;
        }
    }
    float minDiff = 4.71828182846;
    for (int a = 0; a < 4; a++) {
        colors[a] /= radiusSquare;
        colorsSquare[a] = abs(colorsSquare[a] / radiusSquare - colors[a] * colors[a]);
        float diff = colorsSquare[a].r + colorsSquare[a].g + colorsSquare[a].b;
        if (diff < minDiff) {
            minDiff = diff;
            fragColor = vec4(colors[a], texture(InSampler, texCoord).a);
        }
    }
}