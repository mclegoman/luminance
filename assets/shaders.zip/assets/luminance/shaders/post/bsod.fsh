#version 150

in vec2 texCoord;
uniform sampler2D InSampler;
uniform sampler2D BSOD1Sampler;
uniform sampler2D BSOD2Sampler;
uniform vec4 BackgroundColor;
uniform vec4 LabelColor;
uniform vec4 TextColor;
out vec4 fragColor;

void main(){
	vec3 inCol = texture(InSampler, texCoord).rgb;
	inCol = mix(inCol, BackgroundColor.rgb, BackgroundColor.a);
    vec4 bsod1Col = texture(BSOD1Sampler, vec2(texCoord.x, 1.0 - texCoord.y));
    inCol = mix(inCol, LabelColor.rgb, bsod1Col.a * LabelColor.a);
    vec4 bsod2Col = texture(BSOD2Sampler, vec2(texCoord.x, 1.0 - texCoord.y));
    inCol = mix(inCol, TextColor.rgb, bsod2Col.a * TextColor.a);
    fragColor = vec4(inCol, 1.0);
}
