#version 150

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

uniform float BumpScale;
uniform float ColorSteps;

float near = 0.1;
float far = 1000.0;
float LinearizeDepth(float depth) {
    float z = depth * 2.0 - 1.0;
    return (near * far) / (far + near - z * (far - near));
}

void main() {
    vec4 col = texture(InSampler, texCoord);

    float depth = LinearizeDepth(texture(DepthSampler, texCoord).r);
    float depthUp = LinearizeDepth(texture(DepthSampler, texCoord+vec2(0.0, oneTexel.y)).r);

    float steps = ColorSteps*inversesqrt(depth);
    col = floor(col*steps)/steps;

    float diff = abs(depth-depthUp);
    col = col+(BumpScale*diff);

    fragColor = vec4(col.rgb, 1.0);
}